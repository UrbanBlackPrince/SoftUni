﻿namespace Zoo
{
    public class StartUp
    {
       public static void Main(string[] args)
        {
            var snake = new Snake("gogi");
            var bear = new Bear("memo");
            var bearname = bear.Name;

        }
    }
}